// // get an input from the user
// // if the number is divisible by 3 print fizz
// // if the number is divisible by 5 print buzz
// // if the number is divisible by both 3 and 5 print fizzbuzz

// let value =  parseInt(prompt("Please enter any number"))

// // console.log(typeof(value))
// // for(let i=1; i<=value; i++){
// //     // console.log(i)
// //     if(i%3 ==0 & i%5==0){
// //        console.log("Fizz buzz")
// //    }
// //     else if(i%3==0){
// //         console.log("fizz")
// //     }
// //     else if(i%5==0){
// //         console.log("buzz")
// //     }
// //     else{
// //         console.log(i)
// // }
// // }


// // write a program that reads in 10 numbers and print the third number

// // read x as input
// // loop through this to find the third number

// let x = Number(prompt("Enter your number:"))
// let max =0
// for(let i =0; i<=x;i++){
//     max = i-0
 
// }
// console.log(max)
